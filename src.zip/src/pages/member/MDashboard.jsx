import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/authContext';
import axios from 'axios';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CircularProgress,
  Button,
  List,
  ListItem,
  ListItemText,
  Divider,
  Box
} from '@mui/material';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import DescriptionIcon from '@mui/icons-material/Description';

const MemberDashboard = () => {
  const { user } = useContext(AuthContext);
  const [enrolledClasses, setEnrolledClasses] = useState([]);
  const [workoutPlans, setWorkoutPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [classesRes, plansRes] = await Promise.all([
          axios.get(`/api/classes/member/${user._id}`),
          axios.get(`/api/workout-plans/member/${user._id}`)
        ]);
        setEnrolledClasses(classesRes.data.data || []);
        setWorkoutPlans(plansRes.data.data || []);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user._id]);

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} />
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Typography color="error">{error}</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Welcome, {user.name}
      </Typography>

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <FitnessCenterIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Your Classes</Typography>
              </Box>
              
              {enrolledClasses.length > 0 ? (
                <List>
                  {enrolledClasses.slice(0, 3).map((cls, index) => (
                    <React.Fragment key={cls._id}>
                      <ListItem>
                        <ListItemText
                          primary={cls.name}
                          secondary={`${new Date(cls.schedule).toLocaleString()} with ${cls.instructor}`}
                        />
                      </ListItem>
                      {index < enrolledClasses.length - 1 && <Divider />}
                    </React.Fragment>
                  ))}
                </List>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  You are not enrolled in any classes yet.
                </Typography>
              )}
              
              <Button
                variant="outlined"
                fullWidth
                sx={{ mt: 2 }}
                onClick={() => navigate('/member/classes')}
              >
                {enrolledClasses.length > 0 ? 'View All Classes' : 'Browse Classes'}
              </Button>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <DescriptionIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Your Workout Plans</Typography>
              </Box>
              
              {workoutPlans.length > 0 ? (
                <List>
                  {workoutPlans.slice(0, 3).map((plan, index) => (
                    <React.Fragment key={plan._id}>
                      <ListItem>
                        <ListItemText
                          primary={plan.title}
                          secondary={`Assigned on ${new Date(plan.assignedDate).toLocaleDateString()}`}
                        />
                        <Button 
                          size="small"
                          href={`/uploads/${plan.file}`}
                          target="_blank"
                        >
                          View
                        </Button>
                      </ListItem>
                      {index < workoutPlans.length - 1 && <Divider />}
                    </React.Fragment>
                  ))}
                </List>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  You don't have any workout plans assigned yet.
                </Typography>
              )}
              
              <Button
                variant="outlined"
                fullWidth
                sx={{ mt: 2 }}
                onClick={() => navigate('/member/workout-plans')}
              >
                {workoutPlans.length > 0 ? 'View All Plans' : 'Check Back Later'}
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Upcoming Schedule Section */}
      <Card sx={{ mt: 4 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Upcoming Schedule
          </Typography>
          {enrolledClasses.length > 0 ? (
            <List>
              {enrolledClasses
                .filter(cls => new Date(cls.schedule) > new Date())
                .sort((a, b) => new Date(a.schedule) - new Date(b.schedule))
                .slice(0, 3)
                .map((cls, index) => (
                  <React.Fragment key={cls._id}>
                    <ListItem>
                      <ListItemText
                        primary={cls.name}
                        secondary={`${new Date(cls.schedule).toLocaleString()} - ${cls.instructor}`}
                      />
                    </ListItem>
                    {index < enrolledClasses.length - 1 && <Divider />}
                  </React.Fragment>
                ))}
            </List>
          ) : (
            <Typography variant="body2" color="text.secondary">
              No upcoming classes scheduled.
            </Typography>
          )}
        </CardContent>
      </Card>
    </Container>
  );
};

export default MemberDashboard;