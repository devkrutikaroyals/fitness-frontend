import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../../context/authContext';
import api from '../../utils/api';
import {
  Container,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Button,
  CircularProgress,
  Card,
  CardContent
} from '@mui/material';
import './MWorkoutPlans.css'; // External CSS

const MWorkoutPlans = () => {
  const { user } = useContext(AuthContext);
  const [workoutPlans, setWorkoutPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWorkoutPlans = async () => {
      if (!user?._id) return;

      try {
        const res = await api.get(`/workout-plans/member/${user._id}`);
        setWorkoutPlans(res.data.data || []);
      } catch (err) {
        console.error('Error fetching workout plans:', err);
        setWorkoutPlans([]);
      } finally {
        setLoading(false);
      }
    };

    fetchWorkoutPlans();
  }, [user?._id]);

  if (loading) {
    return (
      <Container maxWidth="lg" className="loading-container">
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" className="workout-container">
      <Card className="workout-card">
        <CardContent>
          <Typography variant="h4" gutterBottom>
            Your Workout Plans
          </Typography>

          {workoutPlans.length > 0 ? (
            <List>
              {workoutPlans.map(plan => (
                <ListItem key={plan._id} className="workout-list-item">
                  <ListItemText
                    primary={plan.title}
                    secondary={
                      <>
                        <div>{plan.description}</div>
                        <div>
                          Assigned on:{' '}
                          {plan.assignedDate
                            ? new Date(plan.assignedDate).toLocaleDateString()
                            : 'N/A'}
                        </div>
                      </>
                    }
                  />
                  <ListItemSecondaryAction>
                    <Button
                      variant="contained"
                      color="primary"
                      href={`/uploads/${plan.file}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Download PDF
                    </Button>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          ) : (
            <Typography variant="body1" color="textSecondary">
              You don't have any workout plans assigned yet.
            </Typography>
          )}
        </CardContent>
      </Card>
    </Container>
  );
};

export default MWorkoutPlans;
