import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../../context/authContext';
import axios from 'axios';
import {
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  TextField,
  CircularProgress,
  Chip
} from '@mui/material';
import { Link } from 'react-router-dom';
import './MClasses.css';

const MClasses = () => {
  const { user } = useContext(AuthContext);
  const [classes, setClasses] = useState([]);
  const [enrolledClasses, setEnrolledClasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!user?._id) return;

      try {
        const [allClassesRes, enrolledRes] = await Promise.all([
          axios.get('/api/members/classes'),
          axios.get('/api/members/my-classes')
        ]);

        const allClasses = allClassesRes.data.data || [];
        const enrolled = enrolledRes.data.data || [];

        setClasses(allClasses);
        setEnrolledClasses(enrolled.map(c => c._id));
      } catch (err) {
        console.error('Error loading classes:', err);
        setClasses([]);
        setEnrolledClasses([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user?._id]);

  const handleSearchChange = (e) => setSearchTerm(e.target.value);

  const filteredClasses = classes.filter(cls =>
    cls.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cls.instructor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEnroll = async (classId) => {
    try {
      await axios.put(`/api/members/classes/${classId}/enroll`);
      setEnrolledClasses(prev => [...prev, classId]);
    } catch (err) {
      console.error('Enrollment error:', err);
    }
  };

  if (loading) {
    return (
      <Container maxWidth="lg" className="loading-container">
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" className="mclasses-container">
      <Typography variant="h4" gutterBottom>
        Available Classes
      </Typography>

      <TextField
        label="Search Classes"
        variant="outlined"
        fullWidth
        margin="normal"
        value={searchTerm}
        onChange={handleSearchChange}
      />

      <Grid container spacing={3}>
        {filteredClasses.map(cls => (
          <Grid item xs={12} sm={6} md={4} key={cls._id}>
            <Card className="class-card">
              <CardContent>
                <Typography variant="h6">{cls.name}</Typography>
                <Typography color="textSecondary">{cls.instructor}</Typography>
                <Typography variant="body2">{cls.description}</Typography>
                <Typography variant="body2">
                  <strong>Schedule:</strong> {cls.schedule ? new Date(cls.schedule).toLocaleString() : 'N/A'}
                </Typography>
                <Typography variant="body2">
                  <strong>Duration:</strong> {cls.duration || 0} minutes
                </Typography>
                <div className="chip-container">
                  <Chip
                    label={`${cls.enrolledMembers?.length || 0}/${cls.capacity || 0}`}
                    color={(cls.enrolledMembers?.length || 0) >= (cls.capacity || 0) ? 'error' : 'primary'}
                  />
                </div>
              </CardContent>
              <CardActions>
                {enrolledClasses.includes(cls._id) ? (
                  <Button size="small" color="primary" disabled>
                    Already Enrolled
                  </Button>
                ) : (cls.enrolledMembers?.length || 0) >= (cls.capacity || 0) ? (
                  <Button size="small" color="error" disabled>
                    Class Full
                  </Button>
                ) : (
                  <Button size="small" color="primary" onClick={() => handleEnroll(cls._id)}>
                    Enroll Now
                  </Button>
                )}
                <Button size="small" component={Link} to={`/member/classes/${cls._id}`}>
                  Details
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default MClasses;
